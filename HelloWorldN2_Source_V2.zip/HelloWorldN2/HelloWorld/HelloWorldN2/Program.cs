using System;
using System.ComponentModel;
using System.Drawing;
using NenoForms = Neonode.Forms;
using WinForms = System.Windows.Forms;

namespace HelloWorldN2
{
    static class Program
    {
        static void Main()
        {
            frmHello HelloForm = new frmHello();
            HelloForm.Show();
        }
    }

    class frmHello
    {
        IntPtr _Handle;
        
        public void Show()
        {
            NenoForms.CustomView HelloView = new Neonode.Forms.CustomView();
            _Handle = HelloView.Handle;
            HelloView.Title.Text = "HelloWorldN2";
            HelloView.Description.Text = "HelloWorld application for the N2";
            HelloView.ToolsSweep.Enabled = true;
            HelloView.ToolsSweep.Occurred += new CancelEventHandler(ToolsSweep_Occurred);
            HelloView.Paint += new EventHandler<Neonode.Forms.PaintEventArgs>(HelloView_Paint);
            HelloView.ShowDialog();
        }

        void HelloView_Paint(object sender, Neonode.Forms.PaintEventArgs e)
        {
            Font fnt = new Font("Tahoma", 12, FontStyle.Bold);
            Graphics g = e.Graphics;

            g.DrawString("Hello World :-)", fnt, new SolidBrush(Color.White), 12, 39);
        }

        void ToolsSweep_Occurred(object sender, CancelEventArgs e)
        {
            NenoForms.MessageBox.Show(_Handle, "HelloWorld MessageBox", "MessageBox");
        }
    }
}